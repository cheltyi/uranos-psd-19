Uranos app design preview

Images extracted from the provided 19.psd template.
This is a frontend demonstration, not an executable application.
